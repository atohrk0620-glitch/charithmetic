# MIT License
# Copyright (c) 2025 Hiroki & Chappie
# See LICENSE.txt in the project root for license information.